Using folium with flask
=======================

A very common use case is to use folium with in a flask app.
The trick is to return folium's HTML representation.
Here is an example on how to d that:


.. literalinclude:: ../examples/flask_example.py