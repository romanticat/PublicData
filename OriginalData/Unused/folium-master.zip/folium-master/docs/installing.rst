Installing
==========

Requirements
------------
::

 branca, jinja2 and requests.

Some functionalities may require extra dependencies
`numpy`, `pandas`, `geopandas`, `altair`, etc.


Installation
------------
::

$ pip install folium

or

::

$ conda install folium -c conda-forge
