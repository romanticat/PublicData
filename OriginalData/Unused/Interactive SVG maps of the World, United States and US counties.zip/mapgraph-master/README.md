## Interactive SVG maps of the World, United States and US counties. 

Displays node name on mouse hover. 

Opens Wikipdia page on mouse click. 

Visualization of US census data. Sandbox for graph traversal algorithms (each county is a node)

![Screenshot](thumbnail.png?raw=true "Screenshot")

