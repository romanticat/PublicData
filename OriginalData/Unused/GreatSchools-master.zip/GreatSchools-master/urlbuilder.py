""" author: @odoland
Module for producing URLS """

from bs4 import BeautifulSoup
from collections import namedtuple
import re
import requests

def text2url_generator(path_to_file):
	""" Generator function that returns the URL for each State/Abbr given the file 
	input: path_to_file (string) 
	output - yields a tuple:-  URL (string) , statename (string)
	"""
	URL = "https://www.greatschools.org/schools/districts/{state}/{abbr}"

	with open("statez.csv", "r") as finp:
		for line in finp:
			state, abbr = line.strip().split(",")
			yield URL.format(state=state,abbr=abbr), abbr

def state_info_generator(state_url, driver):
	""" Generator function that gets the url for every Unified School district 
	Driver can then go inside these URLs to collect: website and other information
	input: driver (Selenium driver object)
	output - 
	Each district will yield a:
	[DistrictURL, City, County]
	"""
	
	# Produce a named tuple for every district in that state containing a url, city, and county name
	District = namedtuple('District', 'url city county')
	
	# Get the link of all the districts in that state
	if driver:
		driver.get(state_url)
		html = driver.page_source
	else:
		html = requests.get(state_url).text

	soup = BeautifulSoup( html, 'html.parser')
	links = soup.find_all("td", class_=re.compile("city-district-link"))

	# Collect city name, county name and the url
	for i in range(0, len(links), 3):
		
		url = f"https://www.greatschools.org{links[i].a['href']}"
		city = links[i+1].text.strip()
		county = links[i+2].text.strip()

		yield District(url=url, city=city, county=county)
		


if __name__ == '__main__':


	# test = text2url_generator('statez.csv')
	# for url in test:
	# 	print(url)

	from selenium import webdriver
	from bs4 import BeautifulSoup
	import re

	import argparse

	# Custom Imports


	CHROME_DRIVER = '/home/orlando/Projects/Autograder/chromedriver.exe'
	STATES_FILE = 'statez.csv'

	driver = webdriver.Chrome(executable_path=CHROME_DRIVER)
	
	z = text2url_generator(STATES_FILE)
	url, abbr = next(z)
	a = state_info_generator(url, driver)
	print(next(a))
