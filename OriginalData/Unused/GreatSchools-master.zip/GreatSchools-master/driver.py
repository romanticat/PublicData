import re
import argparse
from bs4 import BeautifulSoup
from selenium import webdriver

CHROME_DRIVER = '/mnt/f/home/GitHub/GreatSchools/chromedriver.exe'

STATES_FILE = 'statez.csv'


def extract_columns_for_district(url, driver, logger_file):
    """ Driver goes to the URL given, takes in every district in that url
    and extracts the :
    district name, phone #, website link, school count and grades
    Returns it as a tuple in that order
    """

    driver.get(url)
    html = driver.page_source
    soup = BeautifulSoup(html, 'html.parser')

    # Get District title
    try:
        district = soup.find("div", class_="district-hero-title").text
    except AttributeError:
        district = "no district name"
        print("LOGGING: No district found for {url}")
        print("No district found for {url}", file=logger_file)

    # Get Phone
    contact_info = soup.find("div", class_="district-hero-contact-info")
    pat = re.compile(r"(\d{3}[-\.\s]??\d{3}[-\.\s]??\d{4}|\(\d{3}\)\s*\d{3}[-\.\s]??\d{4}|\d{3}[-\.\s]??\d{4})")

    try:
        phone = re.findall(pat, contact_info.getText(separator=u' '))[0]
    except IndexError:
        phone = "no phone #"
        print("LOGGING: No phone found for {url}")
        print("No phone found for {url}", file=logger_file)


    # Get site (if it has any)
    try:
        website = contact_info.find("span", class_="badge-and-content link").find('a', class_="content")['href']
    except AttributeError:
        website = "no website"
        print(f"LOGGING: Could not find a website for {url}")
        print(f"No website for {url}", file=logger_file )

    # Get School count and grades
    try:
        stats = soup.find("div", class_="district-hero-stats").getText(separator=u'|').split('|')

        for i in range(0, len(stats), 2):
            if stats[i] == 'SCHOOLS':
                schoolcount = stats[i+1]
            elif stats[i] == 'GRADES':
                grades = stats[i+1]
            else:
                continue

    except AttributeError:
        schoolcount = "not found"
        grades = "not found"
        print(f"LOGGING: Could not find stats (schoolcount, grades) section for: {url}")
        print(f"No schoolcount and/or grades for {url}", file=logger_file)



    return district, phone, website, schoolcount, grades


if __name__ == '__main__':

    from urlbuilder import text2url_generator, state_info_generator

    # File to keep track of error logs
    logger_file = open(f"error_logs.txt", "a")

    # First, create the list of all the states and their URLs
    STATES_FILE = "statez.csv"
    states_urls = text2url_generator(STATES_FILE)

    driver = webdriver.Chrome(executable_path=CHROME_DRIVER)

    # For each state, we will produce the link of all its districts (url, city, county)
    for state_link, state_abbr in states_urls:

        print(f"Going to {state_abbr} url: {state_link}")

        with open(f"output/{state_abbr}.csv", "w") as fout: # Open a new file for each state

            template = "{Name},{City},{CountyName},{PhoneNum},{Website},{SchoolCt},{Grades}"

            for link, city, county in state_info_generator(state_link, driver):

                try:
                    district, phone, website, schoolcount, grades = extract_columns_for_district(link, driver, logger_file)
                except: # Execution must not stop in any case
                    district = phone = website = schoolcount = grades = "ERROR"
                    print(f"ERROR100: Something wrong with {link}. Saving to logger file with ERROR100 flag. ")
                    print(f"ERROR100 with {link}", file=logger_file)

                line = template.format( Name=district
                            ,City=city
                            ,CountyName=county
                            ,PhoneNum=phone
                            ,Website=website
                            ,SchoolCt=schoolcount
                            ,Grades=grades)
                print(f"{district} {city} {county} {phone} {website} {schoolcount} {grades}")
                print(line, file=fout)








