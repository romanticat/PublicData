# Great Schools Data 
Scraping tool to extract all unified school districts across all states in the US

Python modules:
```
selenium
bs4 (beautifulsoup)
re (regular expressions)
```

## video demos:
(recorded using Windows 10's built in XBOX screen recorder - which recorded browser + terminal seperately)
https://youtu.be/_Re8U8amxck
https://youtu.be/X03zNsU4qN0

